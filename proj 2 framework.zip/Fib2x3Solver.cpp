#include "Fib2x3Solver.h"

Fib2x3Solver::Fib2x3Solver()
{
}

void Fib2x3Solver::initialize(int argc, char* argv[])
{
	
}

double Fib2x3Solver::evaluteExpectedScore(int arrayboard[2][3])
{
	return 0;
}

// 0: up
// 1: right
// 2: down
// 3: left
// -1: cannot move
int Fib2x3Solver::findBestMove(int arrayboard[2][3])
{
	return -1;
}

/**********************************
You can implement any additional functions
you may need.
**********************************/
