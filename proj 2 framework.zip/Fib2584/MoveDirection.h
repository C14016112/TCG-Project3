#ifndef __MOVEDIRECTION_H__
#define __MOVEDIRECTION_H__

enum MoveDirection
{
	MOVE_UP, MOVE_RIGHT, MOVE_DOWN, MOVE_LEFT, CANNOT_MOVE
};

#endif